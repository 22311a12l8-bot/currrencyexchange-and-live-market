# SVCexchange - Global Currency Exchange Platform

A comprehensive, real-time currency exchange platform built with React, Express.js, and PostgreSQL. Features live exchange rates, interactive charts, conversion history, and dark mode support for 170+ world currencies.

![SVCexchange Banner](https://img.shields.io/badge/SVCexchange-Global%20Currency%20Platform-blue?style=for-the-badge)

## 🌟 Features

- **170+ World Currencies** - Complete support with country flags and symbols
- **Real-time Exchange Rates** - Live data with automatic updates
- **Interactive Charts** - Historical exchange rate visualization with multiple timeframes
- **Conversion History** - 7-day retention with filtering and export capabilities
- **Dark Mode Support** - System preference detection with manual toggle
- **CSV Export** - Download conversion history data
- **Responsive Design** - Works seamlessly on desktop and mobile devices
- **Professional UI** - Built with shadcn/ui and Tailwind CSS

## 🚀 Quick Start

### Prerequisites

- Node.js 20+ 
- PostgreSQL database
- npm or yarn

### Installation

1. **Clone the repository**
```bash
git clone https://github.com/yourusername/svcexchange.git
cd svcexchange
```

2. **Install dependencies**
```bash
npm install
```

3. **Set up environment variables**
```bash
# Copy the example environment file
cp .env.example .env

# Add your database connection string
DATABASE_URL=your_postgresql_connection_string
```

4. **Initialize the database**
```bash
npm run db:push
```

5. **Start the development server**
```bash
npm run dev
```

The application will be available at `http://localhost:5000`

## 🏗️ Architecture

### Tech Stack

- **Frontend**: React + TypeScript + Vite
- **Backend**: Express.js + TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **UI**: shadcn/ui + Tailwind CSS
- **Charts**: Recharts
- **State Management**: TanStack Query

### Project Structure

```
svcexchange/
├── client/                 # React frontend
│   ├── src/
│   │   ├── components/     # Reusable UI components
│   │   ├── pages/          # Application pages
│   │   ├── lib/            # Utilities and configurations
│   │   └── hooks/          # Custom React hooks
├── server/                 # Express.js backend
│   ├── services/           # Business logic
│   ├── routes.ts           # API endpoints
│   ├── storage.ts          # Database operations
│   └── db.ts              # Database configuration
├── shared/                 # Shared TypeScript types
│   └── schema.ts          # Database schema and types
└── package.json
```

## 🔧 Configuration

### Environment Variables

```bash
# Database
DATABASE_URL=postgresql://username:password@localhost:5432/svcexchange
PGHOST=localhost
PGPORT=5432
PGUSER=username
PGPASSWORD=password
PGDATABASE=svcexchange

# Optional: External Exchange Rate API
EXCHANGE_API_KEY=your_api_key
```

### Database Schema

The application uses two main tables:

- **exchange_rates** - Stores currency exchange rates with timestamps
- **conversions** - Tracks user conversion history (7-day retention)

## 📊 API Endpoints

### Currency Conversion
- `POST /api/convert` - Convert between currencies
- `GET /api/currencies/popular` - Get popular currencies with trends

### Exchange Rates
- `GET /api/exchange-rates/:base` - Get exchange rates for base currency

### Conversion History
- `GET /api/conversions/recent` - Get recent conversions with filtering
- `GET /api/conversions/export` - Export conversions as CSV
- `POST /api/conversions/cleanup` - Manually trigger cleanup

## 🎨 Features in Detail

### Currency Converter
- Real-time conversion with live exchange rates
- Support for 170+ world currencies
- Currency swap functionality
- Share conversion results

### Interactive Charts
- Multiple timeframes (7D, 1M, 3M, 1Y)
- Responsive design with trend indicators
- Real-time data updates

### History Management
- Automatic 7-day data retention
- Date-based filtering (1d, 3d, 7d, 1w, 2w)
- CSV export functionality
- Daily automatic cleanup at 2 AM

### Dark Mode
- System preference detection
- Manual toggle option
- Consistent theming across all components
- High contrast for better visibility

## 🚀 Deployment

### Production Build

```bash
# Build the application
npm run build

# Start production server
npm start
```

### Docker Deployment

```dockerfile
FROM node:20-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
RUN npm run build
EXPOSE 5000
CMD ["npm", "start"]
```

## 🧪 Development

### Available Scripts

```bash
npm run dev          # Start development server
npm run build        # Build for production
npm run db:push      # Push database schema changes
npm run db:generate  # Generate database migrations
npm run db:studio    # Open database studio
```

### Code Style

- TypeScript for type safety
- ESLint + Prettier for code formatting
- Conventional commits for version control

## 🔒 Security

- Input validation with Zod schemas
- SQL injection prevention with parameterized queries
- Rate limiting for API endpoints
- CORS configuration for secure API access

## 🌍 Currency Support

The platform supports 170+ world currencies including:

- Major currencies (USD, EUR, GBP, JPY, etc.)
- Cryptocurrencies
- Regional currencies
- Historical currencies

Each currency includes:
- Country flag emoji
- Currency symbol
- Full currency name
- Real-time exchange rates

## 📱 Mobile Support

- Responsive design for all screen sizes
- Touch-friendly interface
- Progressive Web App capabilities
- Offline support for recent conversions

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- [shadcn/ui](https://ui.shadcn.com) for the beautiful UI components
- [Recharts](https://recharts.org) for interactive charts
- [Drizzle ORM](https://orm.drizzle.team) for type-safe database operations
- [TanStack Query](https://tanstack.com/query) for data fetching and caching

## 📞 Support

For support, email support@svcexchange.com or join our Discord community.

---

Made with ❤️ by the SVCexchange team