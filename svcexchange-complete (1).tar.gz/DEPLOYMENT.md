# SVCexchange Deployment Guide

## Quick Deployment Options

### 1. Replit Deployment (Recommended)
1. Import this repository to Replit
2. Configure environment variables in Replit secrets
3. Enable PostgreSQL database in Replit
4. Run `npm run db:push` to initialize database
5. Click "Deploy" in Replit interface

### 2. Vercel + Neon Database
1. Fork this repository on GitHub
2. Connect to Vercel
3. Create a Neon PostgreSQL database
4. Add environment variables to Vercel
5. Deploy automatically

### 3. Railway Deployment
1. Connect GitHub repository to Railway
2. Add PostgreSQL service
3. Configure environment variables
4. Deploy with one click

### 4. Docker Deployment
```bash
# Clone and build
git clone https://github.com/yourusername/svcexchange.git
cd svcexchange
docker-compose up -d
```

## Environment Variables Required

```bash
DATABASE_URL=postgresql://user:pass@host:5432/dbname
PGHOST=your_host
PGPORT=5432
PGUSER=your_user
PGPASSWORD=your_password
PGDATABASE=svcexchange
```

## Post-Deployment Setup

1. Initialize database schema:
```bash
npm run db:push
```

2. Verify deployment:
- Visit your deployed URL
- Test currency conversion
- Check dark mode toggle
- Test history filtering and export

## Features Verification Checklist

- [ ] Currency converter works with 170+ currencies
- [ ] Interactive charts display correctly
- [ ] Dark mode toggles properly
- [ ] History page shows conversions
- [ ] Filter by date ranges works
- [ ] CSV export downloads successfully
- [ ] 7-day automatic cleanup is scheduled
- [ ] Responsive design on mobile/desktop