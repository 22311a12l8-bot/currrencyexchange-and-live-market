# SVCexchange - Global Currency Exchange Platform

## Overview

SVCexchange is a comprehensive, real-time currency exchange platform built with a React frontend and Express.js backend. The application provides live exchange rate data, interactive historical charts, currency conversion functionality, dark mode support, and conversion history tracking with a modern, responsive user interface covering 170+ world currencies.

## System Architecture

### Full-Stack TypeScript Application
- **Frontend**: React with TypeScript, using Vite as the build tool
- **Backend**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **UI Framework**: shadcn/ui components with Tailwind CSS
- **State Management**: TanStack Query for server state management
- **Routing**: Wouter for client-side routing

### Monorepo Structure
The application follows a monorepo pattern with shared code:
- `client/` - React frontend application
- `server/` - Express.js backend API
- `shared/` - Shared TypeScript schemas and types
- `components.json` - shadcn/ui configuration

## Key Components

### Frontend Architecture
- **Component Library**: Full shadcn/ui implementation with 40+ components
- **Styling**: Tailwind CSS with CSS variables for theming and dark mode support
- **Form Handling**: React Hook Form with Zod validation
- **Data Fetching**: TanStack Query for API calls and caching
- **Theme Management**: Context-based theme provider with localStorage persistence
- **Chart Library**: Recharts for interactive exchange rate visualizations
- **UI Components**: 
  - Currency converter with real-time conversion
  - Interactive exchange rate charts with multiple time ranges
  - Popular currencies display with trend indicators
  - Currency selector with search functionality (170+ currencies)
  - Conversion history page with grouping and statistics
  - Responsive header with navigation and theme toggle
  - Dark/light mode toggle with system preference detection

### Backend Architecture
- **API Structure**: RESTful endpoints for currency operations
- **Exchange Rate Service**: External API integration with fallback mock data
- **Storage Layer**: Abstracted storage interface supporting both memory and database storage
- **Error Handling**: Centralized error handling middleware
- **Logging**: Request/response logging with performance metrics

### Database Schema
- **Exchange Rates Table**: Stores base currency, target currency, rate, and timestamp
- **Conversions Table**: Logs all conversion requests with amounts and rates
- **Decimal Precision**: High-precision decimal fields for accurate financial calculations

## Data Flow

1. **Currency Conversion Process**:
   - Frontend sends conversion request to `/api/convert`
   - Backend validates request data using Zod schemas
   - External exchange rate API fetched (with fallback to mock data)
   - Conversion calculated and stored in database
   - Response sent back with converted amount and rate

2. **Exchange Rate Updates**:
   - Rates fetched from external API on demand
   - Stored in database for caching and historical tracking
   - Frontend displays live rates with periodic updates

3. **Popular Currencies Display**:
   - Backend provides endpoint for popular currency rates
   - Frontend displays with trend indicators and formatting
   - Real-time updates every 30 seconds

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL database connectivity
- **drizzle-orm**: Type-safe SQL toolkit and ORM
- **@tanstack/react-query**: Server state management
- **@radix-ui**: Accessible component primitives
- **zod**: Schema validation
- **wouter**: Lightweight routing

### Development Tools
- **Vite**: Frontend build tool with HMR
- **esbuild**: Backend bundling for production
- **tsx**: TypeScript execution for development
- **tailwindcss**: Utility-first CSS framework

### External APIs
- Exchange rate data from `api.exchangerate-api.io`
- Fallback mock data for development/offline usage

## Deployment Strategy

### Production Build Process
1. Frontend built with Vite to `dist/public`
2. Backend bundled with esbuild to `dist/index.js`
3. Database migrations applied via Drizzle Kit
4. Static assets served from Express in production

### Environment Configuration
- **Development**: TSX for hot reloading, Vite dev server
- **Production**: Node.js serving bundled code
- **Database**: PostgreSQL with connection pooling
- **Port Configuration**: 5000 (configurable via environment)

### Replit Configuration
- Auto-deployment with build process
- PostgreSQL module enabled
- Development workflow with hot reloading
- Port forwarding configured for external access

## Recent Changes

### December 16, 2025
- **App Rebranding**: Renamed from GlobalFX to SVCexchange
- **Dark Mode Implementation**: Added complete dark/light theme support with system preference detection
- **Interactive Charts**: Implemented live exchange rate charts using Recharts with multiple time ranges (7D, 1M, 3M, 1Y)
- **History Page**: Created comprehensive conversion history page with date grouping and statistics
- **Enhanced Currency Support**: Expanded to 170+ world currencies with proper flags and symbols
- **Navigation Enhancement**: Added responsive header with theme toggle and page navigation
- **Theme Provider**: Implemented context-based theme management with localStorage persistence
- **UI Improvements**: Updated all components to support dark mode and improved accessibility

### Technical Enhancements
- Added theme provider with dark/light/system modes
- Integrated Recharts for interactive data visualization
- Enhanced currency database with comprehensive country coverage
- Implemented proper navigation between converter and history pages
- Fixed accessibility warnings in dialog components
- Updated styling system for seamless dark mode transitions

## User Preferences

```
Preferred communication style: Simple, everyday language.
App Name: SVCexchange (updated from GlobalFX)
Features: Dark mode support, interactive charts, comprehensive history tracking
```