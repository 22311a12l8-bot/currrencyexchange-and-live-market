import { useState } from "react";
import { Header } from "@/components/header";
import { CurrencyConverter } from "@/components/currency-converter";
import { PopularCurrencies } from "@/components/popular-currencies";
import { ExchangeRateChart } from "@/components/exchange-rate-chart";
import { BarChart3 } from "lucide-react";

export default function Home() {
  const [chartBaseCurrency, setChartBaseCurrency] = useState("USD");
  const [chartTargetCurrency, setChartTargetCurrency] = useState("EUR");

  const handleCurrencySelect = (code: string) => {
    setChartTargetCurrency(code);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        <CurrencyConverter />
        
        <PopularCurrencies 
          baseCurrency={chartBaseCurrency} 
          onCurrencySelect={handleCurrencySelect}
        />

        <ExchangeRateChart 
          baseCurrency={chartBaseCurrency}
          targetCurrency={chartTargetCurrency}
          onCurrencyChange={(base, target) => {
            setChartBaseCurrency(base);
            setChartTargetCurrency(target);
          }}
        />
      </main>

      {/* Footer */}
      <footer className="bg-card border-t border-border mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                  <BarChart3 className="h-4 w-4 text-primary-foreground" />
                </div>
                <span className="text-xl font-bold">SVCexchange</span>
              </div>
              <p className="text-muted-foreground text-sm">
                Professional currency exchange platform with live rates from global financial markets covering 170+ world currencies.
              </p>
            </div>
            
            <div>
              <h4 className="font-semibold mb-3">Features</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>170+ World Currencies</li>
                <li>Real-time Exchange Rates</li>
                <li>Interactive Historical Charts</li>
                <li>Conversion History</li>
                <li>Dark Mode Support</li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-3">Data Sources</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>Central Bank Rates</li>
                <li>Forex Markets</li>
                <li>Updated Every Minute</li>
                <li>99.9% Uptime</li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-border mt-8 pt-8 flex items-center justify-between">
            <p className="text-sm text-muted-foreground">© 2025 SVCexchange. All rights reserved.</p>
            <div className="flex items-center space-x-6 text-sm text-muted-foreground">
              <a href="#" className="hover:text-foreground">Privacy Policy</a>
              <a href="#" className="hover:text-foreground">Terms of Service</a>
              <a href="#" className="hover:text-foreground">API</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
