import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Header } from "@/components/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { getCurrencyByCode, formatCurrency, formatRate } from "@/lib/currencies";
import { History, ArrowRight, Download, Filter, Calendar } from "lucide-react";
import { type Conversion } from "@shared/schema";

const filterOptions = [
  { value: 'all', label: 'All Time' },
  { value: '1d', label: 'Last 24 Hours' },
  { value: '3d', label: 'Last 3 Days' },
  { value: '7d', label: 'Last 7 Days' },
  { value: '1w', label: 'Last Week' },
  { value: '2w', label: 'Last 2 Weeks' },
];

export default function HistoryPage() {
  const [dateFilter, setDateFilter] = useState('all');
  const { toast } = useToast();

  const { data: conversions, isLoading, error } = useQuery({
    queryKey: ['/api/conversions/recent', { filter: dateFilter }],
    queryFn: async () => {
      const params = new URLSearchParams();
      params.append('limit', '100');
      if (dateFilter !== 'all') {
        params.append('filter', dateFilter);
      }
      
      const response = await fetch(`/api/conversions/recent?${params}`);
      if (!response.ok) {
        throw new Error('Failed to fetch conversion history');
      }
      return response.json() as Promise<Conversion[]>;
    },
    refetchInterval: 30000,
  });

  const handleExport = async () => {
    try {
      const params = new URLSearchParams();
      params.append('limit', '1000');
      if (dateFilter !== 'all') {
        params.append('filter', dateFilter);
      }

      const response = await fetch(`/api/conversions/export?${params}`);
      if (!response.ok) {
        throw new Error('Failed to export data');
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `svcexchange-conversions-${new Date().toISOString().split('T')[0]}.csv`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);

      toast({
        title: "Export Successful",
        description: "Your conversion history has been downloaded as a CSV file.",
      });
    } catch (error) {
      toast({
        title: "Export Failed",
        description: "Failed to export conversion history. Please try again.",
        variant: "destructive",
      });
    }
  };

  const formatTimestamp = (timestamp: Date | string) => {
    const date = new Date(timestamp);
    return {
      date: date.toLocaleDateString('en-US', { 
        month: 'short', 
        day: 'numeric',
        year: 'numeric'
      }),
      time: date.toLocaleTimeString('en-US', { 
        hour: '2-digit', 
        minute: '2-digit' 
      })
    };
  };

  const groupConversionsByDate = (conversions: Conversion[]) => {
    const groups: Record<string, Conversion[]> = {};
    
    conversions.forEach(conversion => {
      const date = formatTimestamp(conversion.timestamp).date;
      if (!groups[date]) {
        groups[date] = [];
      }
      groups[date].push(conversion);
    });
    
    return groups;
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <History className="h-6 w-6 text-primary" />
                <h1 className="text-2xl font-bold">Conversion History</h1>
              </div>
            </div>
            
            <Card>
              <CardContent className="p-6">
                <div className="space-y-4">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <div key={i} className="bg-muted rounded-lg p-4 animate-pulse">
                      <div className="h-4 bg-muted-foreground/20 rounded mb-2"></div>
                      <div className="h-6 bg-muted-foreground/20 rounded mb-2"></div>
                      <div className="h-3 bg-muted-foreground/20 rounded w-1/3"></div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Card>
            <CardContent className="p-6 text-center">
              <History className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">Unable to Load History</h3>
              <p className="text-muted-foreground">There was an error loading your conversion history.</p>
            </CardContent>
          </Card>
        </main>
      </div>
    );
  }

  const groupedConversions = conversions ? groupConversionsByDate(conversions) : {};
  const totalConversions = conversions?.length || 0;

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
        {/* Header Section */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <History className="h-6 w-6 text-primary" />
            <div>
              <h1 className="text-2xl font-bold">Conversion History</h1>
              <p className="text-muted-foreground">
                {totalConversions} conversion{totalConversions !== 1 ? 's' : ''} found
              </p>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <Select value={dateFilter} onValueChange={setDateFilter}>
              <SelectTrigger className="w-40">
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {filterOptions.map((option) => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button variant="outline" size="sm" onClick={handleExport}>
              <Download className="h-4 w-4 mr-2" />
              Export CSV
            </Button>
          </div>
        </div>

        {/* Statistics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="text-2xl font-bold">{totalConversions}</div>
              <p className="text-xs text-muted-foreground">Total Conversions</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="text-2xl font-bold">
                {conversions ? new Set(conversions.map(c => c.fromCurrency)).size : 0}
              </div>
              <p className="text-xs text-muted-foreground">Currencies Used</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="text-2xl font-bold">
                {Object.keys(groupedConversions).length}
              </div>
              <p className="text-xs text-muted-foreground">Active Days</p>
            </CardContent>
          </Card>
        </div>

        {/* Conversion History */}
        {totalConversions === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <History className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">No Conversions Yet</h3>
              <p className="text-muted-foreground mb-4">
                Start converting currencies to see your history here.
              </p>
              <Button>
                Start Converting
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-6">
            {Object.entries(groupedConversions)
              .sort(([a], [b]) => new Date(b).getTime() - new Date(a).getTime())
              .map(([date, dateConversions]) => (
                <Card key={date}>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg flex items-center justify-between">
                      <span>{date}</span>
                      <Badge variant="secondary">
                        {dateConversions.length} conversion{dateConversions.length !== 1 ? 's' : ''}
                      </Badge>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {dateConversions
                      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
                      .map((conversion) => {
                        const fromCurrency = getCurrencyByCode(conversion.fromCurrency);
                        const toCurrency = getCurrencyByCode(conversion.toCurrency);
                        const { time } = formatTimestamp(conversion.timestamp);
                        
                        return (
                          <div
                            key={conversion.id}
                            className="flex items-center justify-between p-4 bg-muted/50 rounded-lg hover:bg-muted/70 transition-colors"
                          >
                            <div className="flex items-center space-x-4">
                              <div className="flex items-center space-x-2">
                                <span className="text-xl">{fromCurrency?.flag || '🏳️'}</span>
                                <div className="text-sm">
                                  <div className="font-medium">
                                    {formatCurrency(parseFloat(conversion.amount), conversion.fromCurrency)}
                                  </div>
                                  <div className="text-muted-foreground">
                                    {conversion.fromCurrency}
                                  </div>
                                </div>
                              </div>
                              
                              <ArrowRight className="h-4 w-4 text-muted-foreground" />
                              
                              <div className="flex items-center space-x-2">
                                <span className="text-xl">{toCurrency?.flag || '🏳️'}</span>
                                <div className="text-sm">
                                  <div className="font-medium">
                                    {formatCurrency(parseFloat(conversion.convertedAmount), conversion.toCurrency)}
                                  </div>
                                  <div className="text-muted-foreground">
                                    {conversion.toCurrency}
                                  </div>
                                </div>
                              </div>
                            </div>
                            
                            <div className="text-right text-sm">
                              <div className="font-medium">
                                Rate: {formatRate(parseFloat(conversion.rate))}
                              </div>
                              <div className="text-muted-foreground">
                                {time}
                              </div>
                            </div>
                          </div>
                        );
                      })}
                  </CardContent>
                </Card>
              ))}
          </div>
        )}
      </main>
    </div>
  );
}