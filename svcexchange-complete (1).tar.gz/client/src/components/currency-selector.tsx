import { useState } from "react";
import { Search, X } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { currencies, getCurrencyByCode } from "@/lib/currencies";
import { type Currency } from "@shared/schema";

interface CurrencySelectorProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  selectedCurrency: string;
  onSelect: (currency: Currency) => void;
  title: string;
}

export function CurrencySelector({ 
  open, 
  onOpenChange, 
  selectedCurrency, 
  onSelect, 
  title 
}: CurrencySelectorProps) {
  const [search, setSearch] = useState("");

  const filteredCurrencies = currencies.filter(currency =>
    currency.code.toLowerCase().includes(search.toLowerCase()) ||
    currency.name.toLowerCase().includes(search.toLowerCase())
  );

  const handleSelect = (currency: Currency) => {
    onSelect(currency);
    onOpenChange(false);
    setSearch("");
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md max-h-96 flex flex-col" aria-describedby="currency-selector-description">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
        </DialogHeader>
        <p id="currency-selector-description" className="sr-only">
          Search and select from available currencies with their country flags and symbols
        </p>
        
        <div className="border-b border-slate-200 pb-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 h-4 w-4" />
            <Input
              placeholder="Search currencies..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>
        
        <div className="flex-1 overflow-y-auto space-y-1">
          {filteredCurrencies.map((currency) => (
            <Button
              key={currency.code}
              variant="ghost"
              className="w-full justify-start h-auto p-3 hover:bg-slate-50"
              onClick={() => handleSelect(currency)}
            >
              <div className="flex items-center space-x-3 w-full">
                <span className="text-2xl">{currency.flag}</span>
                <div className="flex-1 text-left">
                  <div className="flex items-center justify-between">
                    <span className="font-medium text-slate-900">{currency.code}</span>
                    {currency.symbol && (
                      <span className="text-sm text-slate-500">{currency.symbol}</span>
                    )}
                  </div>
                  <p className="text-sm text-slate-500">{currency.name}</p>
                </div>
              </div>
            </Button>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
}
