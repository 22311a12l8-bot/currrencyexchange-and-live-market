import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { getCurrencyByCode } from "@/lib/currencies";
import { Calendar, TrendingUp, TrendingDown } from "lucide-react";

interface ChartData {
  date: string;
  rate: number;
  timestamp: number;
}

interface ExchangeRateChartProps {
  baseCurrency: string;
  targetCurrency: string;
  onCurrencyChange?: (base: string, target: string) => void;
}

const timeRanges = [
  { value: '7d', label: '7 Days' },
  { value: '1m', label: '1 Month' },
  { value: '3m', label: '3 Months' },
  { value: '1y', label: '1 Year' },
];

export function ExchangeRateChart({ 
  baseCurrency = "USD", 
  targetCurrency = "EUR",
  onCurrencyChange 
}: ExchangeRateChartProps) {
  const [timeRange, setTimeRange] = useState('7d');
  
  // Generate mock historical data for the chart
  const generateHistoricalData = (days: number): ChartData[] => {
    const data: ChartData[] = [];
    const baseRate = 0.92; // Mock USD to EUR base rate
    const now = new Date();
    
    for (let i = days; i >= 0; i--) {
      const date = new Date(now.getTime() - i * 24 * 60 * 60 * 1000);
      const volatility = (Math.random() - 0.5) * 0.02; // 2% volatility
      const rate = baseRate + volatility;
      
      data.push({
        date: date.toISOString().split('T')[0],
        rate: parseFloat(rate.toFixed(6)),
        timestamp: date.getTime(),
      });
    }
    
    return data;
  };

  const getDaysFromRange = (range: string): number => {
    switch (range) {
      case '7d': return 7;
      case '1m': return 30;
      case '3m': return 90;
      case '1y': return 365;
      default: return 7;
    }
  };

  const { data: chartData, isLoading } = useQuery({
    queryKey: ['exchange-chart', baseCurrency, targetCurrency, timeRange],
    queryFn: () => generateHistoricalData(getDaysFromRange(timeRange)),
    refetchInterval: 60000, // Refetch every minute
  });

  const baseCurrencyInfo = getCurrencyByCode(baseCurrency);
  const targetCurrencyInfo = getCurrencyByCode(targetCurrency);

  // Calculate trend
  const trend = chartData && chartData.length > 1 
    ? chartData[chartData.length - 1].rate - chartData[0].rate
    : 0;
  const trendPercent = chartData && chartData.length > 1
    ? ((chartData[chartData.length - 1].rate - chartData[0].rate) / chartData[0].rate) * 100
    : 0;

  const formatTooltipValue = (value: number) => {
    return `${value.toFixed(6)} ${targetCurrency}`;
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric' 
    });
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Calendar className="h-5 w-5" />
            <span>Exchange Rate Chart</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-80 bg-muted rounded-lg animate-pulse flex items-center justify-center">
            <div className="text-muted-foreground">Loading chart data...</div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center space-x-2">
            <Calendar className="h-5 w-5" />
            <span>Exchange Rate Chart</span>
          </CardTitle>
          <div className="flex items-center space-x-2">
            <Select value={timeRange} onValueChange={setTimeRange}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {timeRanges.map((range) => (
                  <SelectItem key={range.value} value={range.value}>
                    {range.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
        
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <span className="text-2xl">{baseCurrencyInfo?.flag}</span>
            <span className="font-semibold">{baseCurrency}</span>
            <span className="text-muted-foreground">to</span>
            <span className="text-2xl">{targetCurrencyInfo?.flag}</span>
            <span className="font-semibold">{targetCurrency}</span>
          </div>
          
          <div className="flex items-center space-x-2">
            {trend >= 0 ? (
              <TrendingUp className="h-4 w-4 text-green-600" />
            ) : (
              <TrendingDown className="h-4 w-4 text-red-600" />
            )}
            <span className={`text-sm font-medium ${
              trend >= 0 ? 'text-green-600' : 'text-red-600'
            }`}>
              {trend >= 0 ? '+' : ''}{trendPercent.toFixed(2)}%
            </span>
          </div>
        </div>
      </CardHeader>
      
      <CardContent>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
              <XAxis 
                dataKey="date" 
                tick={{ fontSize: 12 }}
                tickFormatter={formatDate}
                className="text-muted-foreground"
              />
              <YAxis 
                tick={{ fontSize: 12 }}
                domain={['dataMin - 0.001', 'dataMax + 0.001']}
                tickFormatter={(value) => value.toFixed(4)}
                className="text-muted-foreground"
              />
              <Tooltip 
                labelFormatter={(value) => `Date: ${formatDate(value)}`}
                formatter={(value, name) => [formatTooltipValue(value as number), name]}
                contentStyle={{
                  backgroundColor: 'hsl(var(--card))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '6px',
                }}
              />
              <Line 
                type="monotone" 
                dataKey="rate" 
                stroke="hsl(var(--primary))" 
                strokeWidth={2}
                dot={false}
                activeDot={{ r: 4, fill: "hsl(var(--primary))" }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
        
        <div className="mt-4 grid grid-cols-2 gap-4 text-sm">
          <div>
            <span className="text-muted-foreground">Current Rate:</span>
            <span className="ml-2 font-medium">
              {chartData?.[chartData.length - 1]?.rate.toFixed(6)} {targetCurrency}
            </span>
          </div>
          <div>
            <span className="text-muted-foreground">Period Change:</span>
            <span className={`ml-2 font-medium ${
              trend >= 0 ? 'text-green-600' : 'text-red-600'
            }`}>
              {trend >= 0 ? '+' : ''}{trend.toFixed(6)}
            </span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}