import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { ArrowUpDown, Clock, Share2, History, TrendingUp } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { CurrencySelector } from "./currency-selector";
import { getCurrencyByCode, formatCurrency, formatRate } from "@/lib/currencies";
import { apiRequest } from "@/lib/queryClient";
import { type ConversionRequest, type ConversionResponse, type Currency } from "@shared/schema";

export function CurrencyConverter() {
  const [amount, setAmount] = useState<string>("1000.00");
  const [fromCurrency, setFromCurrency] = useState<string>("USD");
  const [toCurrency, setToCurrency] = useState<string>("EUR");
  const [fromSelectorOpen, setFromSelectorOpen] = useState(false);
  const [toSelectorOpen, setToSelectorOpen] = useState(false);
  const [conversionResult, setConversionResult] = useState<ConversionResponse | null>(null);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const convertMutation = useMutation({
    mutationFn: async (request: ConversionRequest) => {
      const response = await apiRequest('POST', '/api/convert', request);
      return response.json();
    },
    onSuccess: (data: ConversionResponse) => {
      setConversionResult(data);
      queryClient.invalidateQueries({ queryKey: ['/api/currencies/popular'] });
    },
    onError: (error) => {
      toast({
        title: "Conversion Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleConvert = () => {
    const numericAmount = parseFloat(amount);
    if (isNaN(numericAmount) || numericAmount <= 0) {
      toast({
        title: "Invalid Amount",
        description: "Please enter a valid positive number",
        variant: "destructive",
      });
      return;
    }

    convertMutation.mutate({
      from: fromCurrency,
      to: toCurrency,
      amount: numericAmount,
    });
  };

  const handleSwapCurrencies = () => {
    setFromCurrency(toCurrency);
    setToCurrency(fromCurrency);
    if (conversionResult) {
      // Automatically convert with swapped currencies
      setTimeout(() => handleConvert(), 100);
    }
  };

  const handleShare = async () => {
    if (!conversionResult) return;
    
    const shareText = `${formatCurrency(conversionResult.amount, conversionResult.from)} = ${formatCurrency(conversionResult.result, conversionResult.to)} (Rate: ${formatRate(conversionResult.rate)})`;
    
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Currency Conversion',
          text: shareText,
        });
      } catch (error) {
        // User cancelled or error occurred
      }
    } else {
      navigator.clipboard.writeText(shareText);
      toast({
        title: "Copied to Clipboard",
        description: "Conversion result copied to clipboard",
      });
    }
  };

  const fromCurrencyInfo = getCurrencyByCode(fromCurrency);
  const toCurrencyInfo = getCurrencyByCode(toCurrency);

  // Auto-convert when amount or currencies change
  const shouldAutoConvert = amount && fromCurrency && toCurrency && !convertMutation.isPending;
  
  return (
    <div className="space-y-6">
      {/* Market Status Banner */}
      <div className="bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200 rounded-lg p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-8 bg-green-100 rounded flex items-center justify-center">
              <TrendingUp className="h-4 w-4 text-green-600" />
            </div>
            <div>
              <p className="text-sm font-medium text-green-800">Markets Open</p>
              <p className="text-xs text-green-600">Last updated: 2 minutes ago</p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-sm font-semibold text-green-800">USD Index: 103.45</p>
            <p className="text-xs text-green-600">+0.23% ↗</p>
          </div>
        </div>
      </div>

      {/* Main Converter Card */}
      <Card className="overflow-hidden">
        {/* Header */}
        <div className="bg-slate-900 text-white p-6">
          <h2 className="text-2xl font-bold mb-2">Currency Converter</h2>
          <p className="text-slate-300">Convert between 170+ world currencies with live exchange rates</p>
        </div>

        <CardContent className="p-6 space-y-8">
          {/* Amount Input */}
          <div className="space-y-3">
            <Label className="text-sm font-medium text-foreground dark:text-foreground">Amount</Label>
            <div className="relative">
              <Input
                type="number"
                placeholder="Enter amount"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="h-14 text-2xl font-bold bg-background dark:bg-card border-2 text-foreground dark:text-foreground focus:ring-2 focus:ring-primary"
                min="0"
                step="0.01"
              />
            </div>
          </div>

          {/* Currency Selection */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* From Currency */}
            <div className="space-y-3">
              <Label className="text-sm font-medium text-foreground dark:text-foreground">From</Label>
              <Button
                variant="outline"
                className="w-full h-16 bg-background dark:bg-card border-2 justify-between hover:bg-muted"
                onClick={() => setFromSelectorOpen(true)}
              >
                <div className="flex items-center space-x-3">
                  <span className="text-2xl">{fromCurrencyInfo?.flag || '🏳️'}</span>
                  <div className="text-left">
                    <p className="font-semibold text-foreground dark:text-foreground">{fromCurrency}</p>
                    <p className="text-sm text-muted-foreground">{fromCurrencyInfo?.name}</p>
                  </div>
                </div>
                <ArrowUpDown className="h-4 w-4 text-muted-foreground" />
              </Button>
            </div>

            {/* To Currency */}
            <div className="space-y-3">
              <Label className="text-sm font-medium text-foreground dark:text-foreground">To</Label>
              <Button
                variant="outline"
                className="w-full h-16 bg-background dark:bg-card border-2 justify-between hover:bg-muted"
                onClick={() => setToSelectorOpen(true)}
              >
                <div className="flex items-center space-x-3">
                  <span className="text-2xl">{toCurrencyInfo?.flag || '🏳️'}</span>
                  <div className="text-left">
                    <p className="font-semibold text-foreground dark:text-foreground">{toCurrency}</p>
                    <p className="text-sm text-muted-foreground">{toCurrencyInfo?.name}</p>
                  </div>
                </div>
                <ArrowUpDown className="h-4 w-4 text-muted-foreground" />
              </Button>
            </div>
          </div>

          {/* Swap Button */}
          <div className="flex justify-center">
            <Button
              onClick={handleSwapCurrencies}
              size="icon"
              className="w-12 h-12 rounded-full shadow-lg hover:shadow-xl transition-all transform hover:scale-105"
            >
              <ArrowUpDown className="h-5 w-5" />
            </Button>
          </div>

          {/* Convert Button */}
          <Button
            onClick={handleConvert}
            className="w-full h-14 text-lg font-semibold"
            disabled={convertMutation.isPending}
          >
            {convertMutation.isPending ? "Converting..." : "Convert"}
          </Button>

          {/* Conversion Result */}
          {conversionResult && (
            <div className="bg-gradient-to-br from-primary/5 to-blue-50 rounded-xl p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-slate-900">Conversion Result</h3>
                <div className="flex items-center space-x-2 text-sm text-slate-600">
                  <Clock className="h-4 w-4" />
                  <span>Updated just now</span>
                </div>
              </div>
              
              <div className="text-center">
                <p className="text-sm text-muted-foreground mb-2">
                  {formatCurrency(conversionResult.amount, conversionResult.from)} =
                </p>
                <p className="text-4xl font-bold text-primary dark:text-primary mb-2">
                  {formatCurrency(conversionResult.result, conversionResult.to)}
                </p>
                <p className="text-sm text-muted-foreground">
                  1 {conversionResult.from} = {formatRate(conversionResult.rate)} {conversionResult.to}
                </p>
              </div>
            </div>
          )}

          {/* Quick Actions */}
          <div className="grid grid-cols-2 gap-4">
            <Button 
              variant="outline" 
              className="h-12"
              onClick={() => window.location.href = '/history'}
            >
              <History className="h-4 w-4 mr-2" />
              View History
            </Button>
            <Button 
              onClick={handleShare}
              disabled={!conversionResult}
              className="h-12"
            >
              <Share2 className="h-4 w-4 mr-2" />
              Share Result
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Currency Selectors */}
      <CurrencySelector
        open={fromSelectorOpen}
        onOpenChange={setFromSelectorOpen}
        selectedCurrency={fromCurrency}
        onSelect={(currency: Currency) => setFromCurrency(currency.code)}
        title="Select From Currency"
      />

      <CurrencySelector
        open={toSelectorOpen}
        onOpenChange={setToSelectorOpen}
        selectedCurrency={toCurrency}
        onSelect={(currency: Currency) => setToCurrency(currency.code)}
        title="Select To Currency"
      />
    </div>
  );
}
