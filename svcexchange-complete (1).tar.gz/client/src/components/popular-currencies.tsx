import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { getCurrencyByCode, formatRate } from "@/lib/currencies";
import { TrendingUp, TrendingDown } from "lucide-react";

interface PopularCurrenciesProps {
  baseCurrency: string;
  onCurrencySelect: (code: string) => void;
}

interface PopularCurrency {
  code: string;
  rate: number;
  change24h: number;
  changePercent24h: number;
}

export function PopularCurrencies({ baseCurrency, onCurrencySelect }: PopularCurrenciesProps) {
  const { data, isLoading, error } = useQuery({
    queryKey: ['/api/currencies/popular', { base: baseCurrency }],
    queryFn: async () => {
      const response = await fetch(`/api/currencies/popular?base=${baseCurrency}`);
      if (!response.ok) {
        throw new Error('Failed to fetch popular currencies');
      }
      return response.json();
    },
    refetchInterval: 30000, // Refetch every 30 seconds
  });

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Popular Currencies</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="bg-slate-50 rounded-lg p-4 animate-pulse">
                <div className="h-4 bg-slate-200 rounded mb-2"></div>
                <div className="h-6 bg-slate-200 rounded mb-2"></div>
                <div className="h-3 bg-slate-200 rounded"></div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Popular Currencies</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-red-600">Failed to load popular currencies</p>
        </CardContent>
      </Card>
    );
  }

  const currencies: PopularCurrency[] = data?.currencies || [];

  return (
    <Card>
      <CardHeader>
        <CardTitle>Popular Currencies</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {currencies.map((currency) => {
            const currencyInfo = getCurrencyByCode(currency.code);
            const isPositive = currency.changePercent24h >= 0;
            
            return (
              <Button
                key={currency.code}
                variant="ghost"
                className="bg-slate-50 rounded-lg p-4 hover:bg-slate-100 h-auto justify-start"
                onClick={() => onCurrencySelect(currency.code)}
              >
                <div className="flex items-center space-x-3 w-full">
                  <span className="text-2xl">{currencyInfo?.flag || '🏳️'}</span>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-slate-900">{currency.code}</span>
                      <span className="text-lg font-bold text-slate-900">
                        {formatRate(currency.rate)}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-slate-500">{currencyInfo?.name}</span>
                      <div className={`flex items-center space-x-1 text-sm ${
                        isPositive ? 'text-green-600' : 'text-red-600'
                      }`}>
                        {isPositive ? (
                          <TrendingUp className="h-3 w-3" />
                        ) : (
                          <TrendingDown className="h-3 w-3" />
                        )}
                        <span>{isPositive ? '+' : ''}{currency.changePercent24h.toFixed(2)}%</span>
                      </div>
                    </div>
                  </div>
                </div>
              </Button>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
