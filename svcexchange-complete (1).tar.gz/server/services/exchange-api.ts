import { type Currency } from "@shared/schema";

interface ExchangeRateAPIResponse {
  success: boolean;
  timestamp: number;
  base: string;
  date: string;
  rates: Record<string, number>;
}

interface ConversionAPIResponse {
  success: boolean;
  query: {
    from: string;
    to: string;
    amount: number;
  };
  info: {
    timestamp: number;
    rate: number;
  };
  result: number;
}

export class ExchangeAPIService {
  private readonly baseUrl = 'https://api.exchangerate-api.io/v4/latest';
  private readonly apiKey = process.env.EXCHANGE_API_KEY || process.env.FIXER_API_KEY || '';
  
  async getExchangeRates(baseCurrency: string = 'USD'): Promise<Record<string, number>> {
    try {
      const response = await fetch(`${this.baseUrl}/${baseCurrency}`);
      
      if (!response.ok) {
        throw new Error(`Exchange API error: ${response.status}`);
      }
      
      const data: ExchangeRateAPIResponse = await response.json();
      
      if (!data.success && 'rates' in data) {
        throw new Error('Exchange API returned unsuccessful response');
      }
      
      return data.rates || {};
    } catch (error) {
      console.error('Error fetching exchange rates:', error);
      // Return mock rates as fallback for development
      return this.getMockRates(baseCurrency);
    }
  }
  
  async convertCurrency(from: string, to: string, amount: number): Promise<{ result: number; rate: number; timestamp: number }> {
    try {
      const rates = await this.getExchangeRates(from);
      const rate = rates[to];
      
      if (!rate) {
        throw new Error(`Exchange rate not found for ${from} to ${to}`);
      }
      
      return {
        result: amount * rate,
        rate,
        timestamp: Date.now(),
      };
    } catch (error) {
      console.error('Error converting currency:', error);
      // Return mock conversion as fallback
      const mockRate = this.getMockRate(from, to);
      return {
        result: amount * mockRate,
        rate: mockRate,
        timestamp: Date.now(),
      };
    }
  }
  
  private getMockRates(baseCurrency: string): Record<string, number> {
    const mockRates: Record<string, Record<string, number>> = {
      USD: {
        EUR: 0.9205,
        GBP: 0.7915,
        JPY: 149.85,
        CAD: 1.3456,
        AUD: 1.5234,
        CHF: 0.8987,
        CNY: 7.2456,
        INR: 83.2456,
        BRL: 5.1234,
        ZAR: 18.9876,
      },
      EUR: {
        USD: 1.0864,
        GBP: 0.8601,
        JPY: 162.89,
        CAD: 1.4623,
        AUD: 1.6551,
        CHF: 0.9764,
        CNY: 7.8734,
        INR: 90.4321,
        BRL: 5.5678,
        ZAR: 20.6432,
      }
    };
    
    return mockRates[baseCurrency] || mockRates.USD;
  }
  
  private getMockRate(from: string, to: string): number {
    const rates = this.getMockRates(from);
    return rates[to] || 1;
  }
}

export const exchangeAPI = new ExchangeAPIService();
