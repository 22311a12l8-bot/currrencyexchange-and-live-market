import { exchangeRates, conversions, type ExchangeRate, type InsertExchangeRate, type Conversion, type InsertConversion } from "@shared/schema";
import { db } from "./db";
import { eq, desc, gte, sql } from "drizzle-orm";

export interface IStorage {
  getExchangeRate(baseCurrency: string, targetCurrency: string): Promise<ExchangeRate | undefined>;
  saveExchangeRate(rate: InsertExchangeRate): Promise<ExchangeRate>;
  saveConversion(conversion: InsertConversion): Promise<Conversion>;
  getRecentConversions(limit?: number): Promise<Conversion[]>;
  getFilteredConversions(dateFilter: string, limit?: number): Promise<Conversion[]>;
  getAllExchangeRates(): Promise<ExchangeRate[]>;
  cleanupOldConversions(): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getExchangeRate(baseCurrency: string, targetCurrency: string): Promise<ExchangeRate | undefined> {
    const [rate] = await db
      .select()
      .from(exchangeRates)
      .where(
        sql`${exchangeRates.baseCurrency} = ${baseCurrency} AND ${exchangeRates.targetCurrency} = ${targetCurrency}`
      )
      .orderBy(desc(exchangeRates.lastUpdated))
      .limit(1);
    return rate || undefined;
  }

  async saveExchangeRate(insertRate: InsertExchangeRate): Promise<ExchangeRate> {
    const [rate] = await db
      .insert(exchangeRates)
      .values(insertRate)
      .returning();
    return rate;
  }

  async saveConversion(insertConversion: InsertConversion): Promise<Conversion> {
    const [conversion] = await db
      .insert(conversions)
      .values(insertConversion)
      .returning();
    return conversion;
  }

  async getRecentConversions(limit: number = 50): Promise<Conversion[]> {
    return await db
      .select()
      .from(conversions)
      .orderBy(desc(conversions.timestamp))
      .limit(limit);
  }

  async getFilteredConversions(dateFilter: string, limit: number = 50): Promise<Conversion[]> {
    const now = new Date();
    let startDate: Date;

    switch (dateFilter) {
      case '1d':
        startDate = new Date(now.getTime() - 24 * 60 * 60 * 1000);
        break;
      case '3d':
        startDate = new Date(now.getTime() - 3 * 24 * 60 * 60 * 1000);
        break;
      case '7d':
        startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        break;
      case '1w':
        startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        break;
      case '2w':
        startDate = new Date(now.getTime() - 14 * 24 * 60 * 60 * 1000);
        break;
      default:
        return this.getRecentConversions(limit);
    }

    return await db
      .select()
      .from(conversions)
      .where(gte(conversions.timestamp, startDate))
      .orderBy(desc(conversions.timestamp))
      .limit(limit);
  }

  async getAllExchangeRates(): Promise<ExchangeRate[]> {
    return await db
      .select()
      .from(exchangeRates)
      .orderBy(desc(exchangeRates.lastUpdated));
  }

  async cleanupOldConversions(): Promise<void> {
    const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
    await db
      .delete(conversions)
      .where(sql`${conversions.timestamp} < ${sevenDaysAgo}`);
  }
}

export const storage = new DatabaseStorage();
