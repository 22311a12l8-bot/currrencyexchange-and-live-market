import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { exchangeAPI } from "./services/exchange-api";
import { insertConversionSchema, type ConversionRequest, type ConversionResponse } from "@shared/schema";
import { z } from "zod";

const conversionRequestSchema = z.object({
  from: z.string().length(3),
  to: z.string().length(3),
  amount: z.number().positive(),
});

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Get exchange rates for a base currency
  app.get("/api/exchange-rates/:base?", async (req, res) => {
    try {
      const baseCurrency = req.params.base?.toUpperCase() || 'USD';
      const rates = await exchangeAPI.getExchangeRates(baseCurrency);
      
      // Save rates to storage
      const savePromises = Object.entries(rates).map(([currency, rate]) =>
        storage.saveExchangeRate({
          baseCurrency,
          targetCurrency: currency,
          rate: rate.toString(),
        })
      );
      
      await Promise.all(savePromises);
      
      res.json({
        base: baseCurrency,
        rates,
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      console.error('Error fetching exchange rates:', error);
      res.status(500).json({ 
        message: 'Failed to fetch exchange rates',
        error: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });
  
  // Convert currency
  app.post("/api/convert", async (req, res) => {
    try {
      const validatedData = conversionRequestSchema.parse(req.body);
      const { from, to, amount } = validatedData;
      
      const conversion = await exchangeAPI.convertCurrency(from.toUpperCase(), to.toUpperCase(), amount);
      
      // Save conversion to storage
      await storage.saveConversion({
        fromCurrency: from.toUpperCase(),
        toCurrency: to.toUpperCase(),
        amount: amount.toString(),
        convertedAmount: conversion.result.toString(),
        rate: conversion.rate.toString(),
      });
      
      const response: ConversionResponse = {
        from: from.toUpperCase(),
        to: to.toUpperCase(),
        amount,
        result: conversion.result,
        rate: conversion.rate,
        lastUpdated: new Date(conversion.timestamp).toISOString(),
      };
      
      res.json(response);
    } catch (error) {
      console.error('Error converting currency:', error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ 
          message: 'Invalid request data', 
          errors: error.errors 
        });
      } else {
        res.status(500).json({ 
          message: 'Failed to convert currency',
          error: error instanceof Error ? error.message : 'Unknown error'
        });
      }
    }
  });
  
  // Get recent conversions
  app.get("/api/conversions/recent", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 50;
      const filter = req.query.filter as string;
      
      let conversions;
      if (filter && filter !== 'all') {
        conversions = await storage.getFilteredConversions(filter, limit);
      } else {
        conversions = await storage.getRecentConversions(limit);
      }
      
      res.json(conversions);
    } catch (error) {
      console.error('Error fetching recent conversions:', error);
      res.status(500).json({ 
        message: 'Failed to fetch recent conversions',
        error: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  // Export conversions as CSV
  app.get("/api/conversions/export", async (req, res) => {
    try {
      const filter = req.query.filter as string || 'all';
      const limit = parseInt(req.query.limit as string) || 1000;
      
      let conversions;
      if (filter !== 'all') {
        conversions = await storage.getFilteredConversions(filter, limit);
      } else {
        conversions = await storage.getRecentConversions(limit);
      }

      // Generate CSV content
      const headers = ['Date', 'Time', 'From Currency', 'To Currency', 'Amount', 'Converted Amount', 'Exchange Rate'];
      const csvRows = [headers.join(',')];
      
      conversions.forEach(conversion => {
        const date = new Date(conversion.timestamp);
        const row = [
          date.toLocaleDateString(),
          date.toLocaleTimeString(),
          conversion.fromCurrency,
          conversion.toCurrency,
          conversion.amount,
          conversion.convertedAmount,
          conversion.rate
        ];
        csvRows.push(row.join(','));
      });

      const csvContent = csvRows.join('\n');
      const filename = `svcexchange-conversions-${new Date().toISOString().split('T')[0]}.csv`;

      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      res.send(csvContent);
    } catch (error) {
      console.error('Error exporting conversions:', error);
      res.status(500).json({ 
        message: 'Failed to export conversions',
        error: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  // Cleanup old conversions (7+ days old)
  app.post("/api/conversions/cleanup", async (req, res) => {
    try {
      await storage.cleanupOldConversions();
      res.json({ message: 'Old conversions cleaned up successfully' });
    } catch (error) {
      console.error('Error cleaning up old conversions:', error);
      res.status(500).json({ 
        message: 'Failed to cleanup old conversions',
        error: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });
  
  // Get popular currencies with current rates
  app.get("/api/currencies/popular", async (req, res) => {
    try {
      const baseCurrency = (req.query.base as string)?.toUpperCase() || 'USD';
      const rates = await exchangeAPI.getExchangeRates(baseCurrency);
      
      // Popular currency codes
      const popularCodes = ['EUR', 'GBP', 'JPY', 'CAD', 'AUD', 'CHF', 'CNY', 'INR'];
      
      const popularCurrencies = popularCodes
        .filter(code => rates[code])
        .map(code => ({
          code,
          rate: rates[code],
          change24h: (Math.random() - 0.5) * 0.02, // Mock 24h change
          changePercent24h: ((Math.random() - 0.5) * 2), // Mock percentage change
        }));
      
      res.json({
        base: baseCurrency,
        currencies: popularCurrencies,
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      console.error('Error fetching popular currencies:', error);
      res.status(500).json({ 
        message: 'Failed to fetch popular currencies',
        error: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
